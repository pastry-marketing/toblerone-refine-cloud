const MAX_PAGES = 10;
const RESULTS_PER_PAGE = 10;
const GOOGLE_SEARCH_PREFIX = "https://www.google.com/search";
const STORAGE_KEY = "tobleroneTrackers";
const CLOUD_CONNECTION_KEY = "tobleroneCloudConnection";
const DASHBOARD_ORIGIN = "https://toblerone-refine-cloud.lovable.app";

chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

async function getCloudConnection() {
  const stored = await chrome.storage.local.get(CLOUD_CONNECTION_KEY);
  return stored[CLOUD_CONNECTION_KEY] || null;
}

async function sha256Hex(value) {
  const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return [...new Uint8Array(bytes)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

// Connects to the dashboard using only its public URL. The dashboard exposes
// its Supabase project (URL + publishable key + shared workspace id) at
// /api/config; the extension then opens its own anonymous session on that
// project, which joins the one shared workspace, and registers a device so its
// runs can sync. No tokens are copied by hand.
async function connectWithDashboardUrl(rawUrl) {
  let origin;
  try {
    origin = new URL(String(rawUrl || "").trim()).origin;
  } catch (_error) {
    throw new Error("Enter the full dashboard URL, for example https://toblerone-refine-cloud.lovable.app.");
  }

  const configResponse = await fetch(`${origin}/api/config`);
  if (!configResponse.ok) throw new Error("Could not reach this dashboard. Check the URL and try again.");
  const config = await configResponse.json();
  const supabaseUrl = config.supabaseUrl;
  const publishableKey = config.supabaseKey;
  const workspaceId = config.workspaceId;
  if (!supabaseUrl || !publishableKey || !workspaceId) {
    throw new Error("This dashboard is not ready to pair yet. Open it once in your browser, then try again.");
  }

  const signInResponse = await fetch(`${supabaseUrl}/auth/v1/signup`, {
    method: "POST",
    headers: { apikey: publishableKey, "content-type": "application/json" },
    body: JSON.stringify({ data: { display_name: "Toblerone extension" }, gotrue_meta_security: {} })
  });
  if (!signInResponse.ok) {
    throw new Error("The dashboard workspace could not start a session. Make sure anonymous sign-ins are enabled.");
  }
  const session = await signInResponse.json();
  const userId = session.user && session.user.id;
  if (!session.access_token || !session.refresh_token || !userId) {
    throw new Error("The dashboard workspace returned an incomplete session.");
  }

  const connection = {
    supabaseUrl,
    publishableKey,
    accessToken: session.access_token,
    refreshToken: session.refresh_token,
    expiresAt: session.expires_at || Math.floor(Date.now() / 1000) + Number(session.expires_in || 3600),
    userId,
    workspaceId,
    dashboardUrl: origin,
    connectedAt: new Date().toISOString()
  };

  const deviceId = await upsertCloudRecord(connection, "extension_devices", "token_hash", {
    workspace_id: workspaceId,
    user_id: userId,
    name: "Toblerone Chrome extension",
    token_hash: await sha256Hex(`chrome:${userId}:${crypto.randomUUID()}`),
    last_seen_at: new Date().toISOString()
  });
  connection.deviceId = deviceId;

  await chrome.storage.local.set({ [CLOUD_CONNECTION_KEY]: connection });
  return syncAllTrackers();
}

async function refreshCloudSession(connection) {
  if (Number(connection.expiresAt || 0) * 1000 > Date.now() + 60000) return connection;
  const response = await fetch(`${connection.supabaseUrl}/auth/v1/token?grant_type=refresh_token`, {
    method: "POST",
    headers: {
      apikey: connection.publishableKey,
      "content-type": "application/json"
    },
    body: JSON.stringify({ refresh_token: connection.refreshToken })
  });
  if (!response.ok) throw new Error("Dashboard connection expired. Open the web dashboard and connect again.");
  const session = await response.json();
  const next = {
    ...connection,
    accessToken: session.access_token,
    refreshToken: session.refresh_token,
    expiresAt: Math.floor(Date.now() / 1000) + Number(session.expires_in || 3600)
  };
  await chrome.storage.local.set({ [CLOUD_CONNECTION_KEY]: next });
  return next;
}

async function cloudRequest(connection, path, options = {}) {
  const active = await refreshCloudSession(connection);
  const response = await fetch(`${active.supabaseUrl}/rest/v1/${path}`, {
    ...options,
    headers: {
      apikey: active.publishableKey,
      authorization: `Bearer ${active.accessToken}`,
      "content-type": "application/json",
      ...(options.headers || {})
    }
  });
  if (!response.ok) {
    const body = await response.text();
    throw new Error(body || `Dashboard sync failed (${response.status}).`);
  }
  if (response.status === 204) return null;
  const text = await response.text();
  return text ? JSON.parse(text) : null;
}

async function upsertCloudRecord(connection, table, onConflict, value) {
  const rows = await cloudRequest(
    connection,
    `${table}?on_conflict=${encodeURIComponent(onConflict)}&select=id`,
    {
      method: "POST",
      headers: { Prefer: "resolution=merge-duplicates,return=representation" },
      body: JSON.stringify(value)
    }
  );
  const id = rows?.[0]?.id;
  if (!id) throw new Error(`Dashboard did not return a ${table} record.`);
  return id;
}

async function syncTrackerRun(tracker, entry) {
  const initialConnection = await getCloudConnection();
  if (!initialConnection) return { ok: false, connected: false };
  const connection = await refreshCloudSession(initialConnection);
  const websiteId = await upsertCloudRecord(connection, "websites", "workspace_id,domain", {
    workspace_id: connection.workspaceId,
    domain: tracker.domain
  });
  const keywordId = await upsertCloudRecord(connection, "keywords", "website_id,keyword", {
    workspace_id: connection.workspaceId,
    website_id: websiteId,
    keyword: tracker.keyword,
    pages_to_check: Math.max(1, Math.min(MAX_PAGES, Number(entry.pages || tracker.pages) || 5)),
    market: "US"
  });
  const history = Array.isArray(tracker.history) ? tracker.history : [];
  const entryIndex = history.findIndex((item) => item.id === entry.id || item.checkedAt === entry.checkedAt);
  const previous = entryIndex > 0 ? history[entryIndex - 1] : null;
  const currentRank = Number.isFinite(entry.rank) ? entry.rank : null;
  const previousRank = Number.isFinite(previous?.rank) ? previous.rank : null;
  const change = currentRank != null && previousRank != null ? previousRank - currentRank : null;
  const clientRunId = entry.id || `${tracker.id}:${entry.checkedAt}`;

  await upsertCloudRecord(connection, "ranking_runs", "workspace_id,client_run_id", {
    workspace_id: connection.workspaceId,
    client_run_id: clientRunId,
    keyword_id: keywordId,
    website_id: websiteId,
    position: currentRank,
    found: currentRank != null,
    previous_position: previousRank,
    position_change: change,
    ranking_url: entry.foundUrl || null,
    result_title: entry.resultTitle || null,
    result_snippet: entry.resultSnippet || null,
    result_domain: entry.resultDomain || null,
    result_page_number: Number.isFinite(entry.resultPageNumber) ? entry.resultPageNumber : null,
    result_position_on_page: Number.isFinite(entry.resultPositionOnPage) ? entry.resultPositionOnPage : null,
    pages_checked: Math.max(1, Math.min(MAX_PAGES, Number(entry.pages || tracker.pages) || 5)),
    search_engine: "google",
    market: "US",
    device_id: connection.deviceId,
    checked_at: entry.checkedAt,
    synced_at: new Date().toISOString()
  });

  await cloudRequest(connection, `extension_devices?id=eq.${encodeURIComponent(connection.deviceId)}`, {
    method: "PATCH",
    headers: { Prefer: "return=minimal" },
    body: JSON.stringify({ last_seen_at: new Date().toISOString(), last_sync_at: new Date().toISOString() })
  });
  return { ok: true, connected: true };
}

async function syncAllTrackers() {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  const trackers = Array.isArray(stored[STORAGE_KEY]) ? stored[STORAGE_KEY] : [];
  let syncedRuns = 0;
  for (const tracker of trackers) {
    for (const entry of Array.isArray(tracker.history) ? tracker.history : []) {
      await syncTrackerRun(tracker, entry);
      syncedRuns += 1;
    }
  }
  return { ok: true, connected: true, syncedRuns };
}

function isTrustedDashboard(sender) {
  try {
    const url = new URL(sender?.url || "");
    return url.protocol === "https:" && (url.hostname === "toblerone-refine-cloud.lovable.app" || url.hostname.endsWith(".lovable.app"));
  } catch (_error) {
    return false;
  }
}

function normalizeHost(hostname) {
  return String(hostname || "").toLowerCase().replace(/^www\./, "");
}

function getTargetDomain(value) {
  const candidate = /^https?:\/\//i.test(value) ? value : `https://${value}`;
  return normalizeHost(new URL(candidate).hostname);
}

function buildSearchUrl(keyword, page) {
  const params = new URLSearchParams({
    q: keyword,
    start: String(page * RESULTS_PER_PAGE),
    num: String(RESULTS_PER_PAGE),
    hl: "en",
    pws: "0",
    filter: "0"
  });
  return `${GOOGLE_SEARCH_PREFIX}?${params}`;
}

function waitForTabComplete(tabId, expectedUrl, timeoutMs = 20000) {
  return new Promise((resolve, reject) => {
    let settled = false;

    const finish = (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(onUpdated);
      if (error) reject(error);
      else resolve();
    };

    const onUpdated = (updatedTabId, changeInfo) => {
      if (updatedTabId === tabId && changeInfo.status === "complete") finish();
    };

    const timer = setTimeout(() => {
      finish(new Error("Google took too long to load. Please try again."));
    }, timeoutMs);

    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.get(tabId)
      .then((tab) => {
        if (tab.status === "complete" && String(tab.url || "").startsWith(expectedUrl)) finish();
      })
      .catch(() => finish(new Error("The temporary search tab was closed.")));
  });
}

function waitForTabUrlChange(tabId, previousUrl, timeoutMs = 20000) {
  return new Promise((resolve, reject) => {
    let settled = false;

    const finish = (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(onUpdated);
      if (error) reject(error);
      else resolve();
    };

    const hasChanged = (tab) => {
      const nextUrl = String(tab?.url || "");
      return tab?.status === "complete" && nextUrl && nextUrl !== previousUrl;
    };

    const onUpdated = (updatedTabId, changeInfo, tab) => {
      if (updatedTabId === tabId && changeInfo.status === "complete" && hasChanged(tab)) finish();
    };

    const timer = setTimeout(() => {
      finish(new Error("Google consent did not finish loading. Please retry."));
    }, timeoutMs);

    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.get(tabId)
      .then((tab) => { if (hasChanged(tab)) finish(); })
      .catch(() => finish(new Error("The temporary search tab was closed.")));
  });
}

function rejectGoogleConsent() {
  const candidates = [...document.querySelectorAll("button, input[type='submit']")];
  const labelFor = (element) => String(
    element.innerText || element.value || element.getAttribute("aria-label") || ""
  ).trim().toLowerCase();

  const rejectButton = candidates.find((element) => {
    const label = labelFor(element);
    return label.includes("reject all") || label.includes("reject everything");
  });
  const fallbackButton = candidates.find((element) => {
    const label = labelFor(element);
    return label.includes("accept all") || label === "i agree" || label === "agree";
  });
  const button = rejectButton || fallbackButton;
  if (!button) return { clicked: false, availableLabels: candidates.map(labelFor).filter(Boolean).slice(0, 8) };

  const action = labelFor(button);
  button.click();
  return { clicked: true, action };
}

async function resolveGoogleConsent(tabId, consentUrl) {
  const execution = await chrome.scripting.executeScript({
    target: { tabId },
    func: rejectGoogleConsent
  });
  const result = execution?.[0]?.result;
  if (!result?.clicked) {
    console.error("[Toblerone] Google consent controls were not found", result);
    throw new Error("Google changed its consent page and Toblerone could not continue the search.");
  }

  console.info("[Toblerone] Google consent resolved", { action: result.action });
  await waitForTabUrlChange(tabId, consentUrl);
}

function readGoogleResults() {
  const normalize = (hostname) => String(hostname || "").toLowerCase().replace(/^www\./, "");
  const cleanText = (value) => String(value || "").replace(/\s+/g, " ").trim();
  const displayedHost = (text) => {
    const match = String(text || "").match(/https?:\/\/(?:www\.)?([a-z0-9.-]+\.[a-z]{2,})(?=[\s/›]|$)/i);
    return match ? normalize(match[1]) : null;
  };
  const unwrap = (rawHref) => {
    if (!rawHref) return null;
    try {
      const url = new URL(rawHref, location.origin);
      const host = normalize(url.hostname);
      if (host === "google.com" || host.endsWith(".google.com")) {
        if (url.pathname === "/url") return url.searchParams.get("q") || url.searchParams.get("url");
        return null;
      }
      return url.protocol === "http:" || url.protocol === "https:" ? url.href : null;
    } catch (_error) {
      return null;
    }
  };
  const findSnippet = (heading, anchor) => {
    let container = heading.closest(".MjjYud") || heading.closest(".g");
    if (!container) {
      container = anchor?.parentElement || heading.parentElement;
      for (let depth = 0; depth < 4 && container?.parentElement; depth += 1) {
        if (cleanText(container.innerText).length >= 80) break;
        container = container.parentElement;
      }
    }

    const snippetSelectors = [
      ".VwiC3b",
      ".IsZvec",
      ".aCOpRe",
      "[data-sncf]",
      "[data-content-feature='1']"
    ];
    for (const selector of snippetSelectors) {
      const text = cleanText(container?.querySelector(selector)?.innerText);
      if (text && text !== cleanText(heading.textContent) && text.length >= 20) return text.slice(0, 500);
    }

    const title = cleanText(heading.textContent);
    const candidates = String(container?.innerText || "")
      .split(/\n+/)
      .map(cleanText)
      .filter((text) => text && text !== title && text.length >= 30 && !/^https?:\/\//i.test(text));
    return (candidates[0] || "").slice(0, 500);
  };

  const bodyText = document.body?.innerText || "";
  const blocked = /unusual traffic|our systems have detected|recaptcha/i.test(bodyText);
  const consent = /before you continue to google|review your privacy options/i.test(bodyText);
  const results = [];
  const seen = new Set();

  for (const heading of document.querySelectorAll("h3")) {
    const anchor = heading.closest("a") || heading.parentElement?.closest("a");
    const directUrl = unwrap(anchor?.getAttribute("href") || anchor?.href);
    const labelHostname = displayedHost(anchor?.innerText);
    if (!directUrl && !labelHostname) continue;

    try {
      const parsed = directUrl ? new URL(directUrl) : null;
      const hostname = parsed ? normalize(parsed.hostname) : labelHostname;
      const resultUrl = parsed?.href || `https://${hostname}`;
      const identity = parsed
        ? `${hostname}${parsed.pathname.replace(/\/$/, "")}${parsed.search}`
        : `${hostname}:${heading.textContent.trim()}`;
      if (!hostname || seen.has(identity)) continue;
      seen.add(identity);
      results.push({
        url: resultUrl,
        hostname,
        title: cleanText(heading.textContent),
        snippet: findSnippet(heading, anchor)
      });
      if (results.length === 10) break;
    } catch (_error) {
      // Ignore malformed result URLs and keep scanning the page.
    }
  }

  return { results, blocked, consent, pageTitle: document.title };
}

async function extractPage(tabId) {
  const execution = await chrome.scripting.executeScript({
    target: { tabId },
    func: readGoogleResults
  });
  return execution?.[0]?.result || { results: [], blocked: false, consent: false };
}

async function runRankCheck(keyword, website, requestedPages) {
  const cleanKeyword = String(keyword || "").trim();
  const cleanWebsite = String(website || "").trim();
  if (!cleanKeyword || !cleanWebsite) throw new Error("Enter both a keyword and a website.");

  let targetDomain;
  try {
    targetDomain = getTargetDomain(cleanWebsite);
  } catch (_error) {
    throw new Error("Enter a valid website, for example example.com.");
  }

  const pagesToScan = Math.max(1, Math.min(MAX_PAGES, Number.parseInt(requestedPages, 10) || 5));
  let searchTab;
  let pagesScanned = 0;
  let resultsSeen = 0;

  try {
    searchTab = await chrome.tabs.create({ url: "about:blank", active: false });

    for (let page = 0; page < pagesToScan; page += 1) {
      const searchUrl = buildSearchUrl(cleanKeyword, page);
      await chrome.tabs.update(searchTab.id, { url: searchUrl });
      await waitForTabComplete(searchTab.id, searchUrl);

      let currentTab = await chrome.tabs.get(searchTab.id);
      let currentUrl = currentTab.url || "";
      if (/consent\.google\.|\/sorry\//i.test(currentUrl)) {
        if (/\/sorry\//i.test(currentUrl)) {
          throw new Error("Google temporarily blocked repeated searches. Wait a few minutes and try again.");
        }
        await resolveGoogleConsent(searchTab.id, currentUrl);
        currentTab = await chrome.tabs.get(searchTab.id);
        currentUrl = currentTab.url || "";
        if (/consent\.google\./i.test(currentUrl)) {
          throw new Error("Google consent could not be completed. Please retry.");
        }
      }

      let pageData = await extractPage(searchTab.id);
      if (!pageData.blocked && !pageData.consent && pageData.results.length === 0) {
        await new Promise((resolve) => setTimeout(resolve, 900));
        pageData = await extractPage(searchTab.id);
      }

      if (pageData.blocked) {
        throw new Error("Google temporarily blocked repeated searches. Wait a few minutes and try again.");
      }
      if (pageData.consent) {
        await resolveGoogleConsent(searchTab.id, currentUrl);
        pageData = await extractPage(searchTab.id);
      }
      if (pageData.results.length === 0) {
        throw new Error("Google loaded, but no organic results were visible on the page. Please retry.");
      }

      pagesScanned += 1;
      resultsSeen += pageData.results.length;

      for (let resultIndex = 0; resultIndex < pageData.results.length; resultIndex += 1) {
        const result = pageData.results[resultIndex];
        const matches = result.hostname === targetDomain || result.hostname.endsWith(`.${targetDomain}`);
        if (matches) {
          return {
            ok: true,
            rank: (page * RESULTS_PER_PAGE) + resultIndex + 1,
            foundUrl: result.url,
            resultTitle: result.title || null,
            resultSnippet: result.snippet || null,
            resultDomain: result.hostname,
            resultPageNumber: page + 1,
            resultPositionOnPage: resultIndex + 1,
            pagesScanned,
            resultsSeen,
            pagesRequested: pagesToScan,
            checkedAt: new Date().toISOString()
          };
        }
      }

      if (page < pagesToScan - 1) {
        await new Promise((resolve) => setTimeout(resolve, 450));
      }
    }

    return {
      ok: true,
      rank: null,
      foundUrl: null,
      resultTitle: null,
      resultSnippet: null,
      resultDomain: null,
      resultPageNumber: null,
      resultPositionOnPage: null,
      pagesScanned,
      resultsSeen,
      pagesRequested: pagesToScan,
      checkedAt: new Date().toISOString()
    };
  } finally {
    if (searchTab?.id) {
      await chrome.tabs.remove(searchTab.id).catch(() => {});
    }
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.target !== "background") return false;

  if (message.type === "OPEN_DASHBOARD") {
    getCloudConnection().then((connection) => {
      const path = connection ? "/overview" : "/extension";
      const url = `${connection?.dashboardUrl || DASHBOARD_ORIGIN}${path}?extensionId=${encodeURIComponent(chrome.runtime.id)}`;
      return chrome.tabs.create({ url });
    }).then(() => sendResponse({ ok: true })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message.type === "GET_SITES") {
    getCloudConnection()
      .then(async (connection) => {
        if (!connection) return sendResponse({ ok: true, sites: [] });
        const rows = await cloudRequest(
          connection,
          `websites?select=domain&workspace_id=eq.${encodeURIComponent(connection.workspaceId)}&order=domain.asc`
        );
        sendResponse({ ok: true, sites: (rows || []).map((row) => row.domain) });
      })
      .catch((error) => sendResponse({ ok: false, sites: [], error: error.message }));
    return true;
  }

  if (message.type === "GET_CONNECTION_STATUS") {
    getCloudConnection()
      .then((connection) => sendResponse({ ok: true, connected: Boolean(connection), lastSyncAt: connection?.lastSyncAt || null }))
      .catch((error) => sendResponse({ ok: false, connected: false, error: error.message }));
    return true;
  }

  if (message.type === "CONNECT_WITH_URL") {
    connectWithDashboardUrl(message.dashboardUrl)
      .then((result) => sendResponse({ ...result, ok: true, connected: true }))
      .catch((error) => {
        console.error("[Toblerone] Dashboard connect failed", error);
        sendResponse({ ok: false, connected: false, error: error.message });
      });
    return true;
  }

  if (message.type === "SYNC_RUN") {
    syncTrackerRun(message.tracker, message.entry)
      .then(sendResponse)
      .catch((error) => {
        console.error("[Toblerone] Dashboard sync failed", error);
        sendResponse({ ok: false, connected: true, error: error.message });
      });
    return true;
  }

  if (message.type !== "CHECK_RANK") return false;

  runRankCheck(message.keyword, message.website, message.pages)
    .then(sendResponse)
    .catch((error) => {
      console.error("[Toblerone] Rank check failed", {
        keyword: message.keyword,
        website: message.website,
        error: error?.message || String(error)
      });
      sendResponse({ ok: false, error: error?.message || "The ranking check could not be completed." });
    });

  return true;
});

chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (!isTrustedDashboard(sender)) {
    sendResponse({ ok: false, error: "This page is not allowed to connect to Toblerone." });
    return false;
  }

  if (message?.type === "TOBLERONE_PING") {
    getCloudConnection()
      .then((connection) => sendResponse({ ok: true, connected: Boolean(connection) }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "TOBLERONE_DISCONNECT") {
    chrome.storage.local.remove(CLOUD_CONNECTION_KEY)
      .then(() => sendResponse({ ok: true, connected: false }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type !== "TOBLERONE_CONNECT") return false;
  const payload = message.payload || {};
  const required = ["supabaseUrl", "publishableKey", "accessToken", "refreshToken", "workspaceId", "deviceId", "dashboardUrl"];
  if (required.some((key) => !payload[key])) {
    sendResponse({ ok: false, error: "The dashboard sent an incomplete connection." });
    return false;
  }

  chrome.storage.local.set({ [CLOUD_CONNECTION_KEY]: { ...payload, connectedAt: new Date().toISOString() } })
    .then(syncAllTrackers)
    .then(sendResponse)
    .catch((error) => {
      console.error("[Toblerone] Extension pairing failed", error);
      sendResponse({ ok: false, error: error.message || "The extension could not sync its data." });
    });
  return true;
});
