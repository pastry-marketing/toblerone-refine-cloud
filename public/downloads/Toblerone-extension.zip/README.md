# Toblerone SEO Rank Tracker

Toblerone is a Chrome/Edge sidebar extension for manually checking where a website appears for a Google keyword. Choose between 1 and 10 result pages, keep up to 365 dated checks per keyword locally, and review ranking movement from either the sidebar or a full reporting dashboard. Each successful check records the exact ranked-page title, URL, domain, Google snippet, results page, and position on that page.

## Install locally

1. Open `chrome://extensions` in Chrome, or `edge://extensions` in Edge.
2. Turn on **Developer mode**.
3. Choose **Load unpacked**.
4. Select this `Toblerone` folder.
5. Pin the extension and select its toolbar icon to open the sidebar.

## Use it

1. Add a target keyword and website domain.
2. Choose how many Google pages to scan (1–10).
3. Select **Add tracker**.
4. Select **Check rank** for one keyword, or **Check all** for every saved keyword.
5. Select **Connect dashboard**, then pair the extension once on the Toblerone web app.
6. Future manual checks sync to the web dashboard automatically.

## Dashboard and exports

- Every completed run is saved locally and, after pairing, in the web dashboard with its date, rank, search depth, movement, and matched URL.
- A rank such as **#37** is also shown as **Page 4 · Result 7**.
- The exact organic result title, landing-page link, domain, and snippet are included in the dashboard and exports.
- The web dashboard includes an overview, trend graph, keyword table, full run history, reports, connected-device status, and settings.
- **Export CSV** creates a simple file for Excel, Google Sheets, or sending to a client.
- **Print / PDF** creates a clean shareable report from the web dashboard.

Data remains in the extension when the web dashboard is not connected. After pairing, the extension securely copies the saved tracker history and each new manual result to that dashboard workspace. Google sometimes shows consent or anti-bot pages; if that happens, Toblerone reports the issue and you can try again later.

Each manual check opens one inactive Google search tab, reuses it for the selected number of pages, and closes it automatically when the check finishes. If Google presents its consent gate, Toblerone selects **Reject all** and continues the search automatically.

## Current scope

- Manual checks only
- Selectable depth from 1 to 10 Google pages / top 10–100 organic results
- Multiple saved keyword/site pairs
- Local and web position history with drop warnings
- Dated run ledger and keyword ranking graph
- CSV and print/PDF reporting
- Domain and subdomain matching
- Chrome sidebar plus a connected full web dashboard
