const STORAGE_KEY = "tobleroneTrackers";
const MAX_PAGES = 10;
const DEFAULT_PAGES = 5;
const checkingIds = new Set();
let trackers = [];
let toastTimer;
let chartResizeObserver;

const elements = {
  form: document.querySelector("#tracker-form"),
  keyword: document.querySelector("#keyword"),
  website: document.querySelector("#website"),
  siteSelect: document.querySelector("#site-select"),
  websiteWrap: document.querySelector("#website-wrap"),
  pages: document.querySelector("#pages"),
  formError: document.querySelector("#form-error"),
  list: document.querySelector("#tracker-list"),
  empty: document.querySelector("#empty-state"),
  checkAll: document.querySelector("#check-all"),
  openDashboard: document.querySelector("#open-dashboard"),
  total: document.querySelector("#total-count"),
  topTen: document.querySelector("#top-ten-count"),
  warnings: document.querySelector("#warning-count"),
  bestRank: document.querySelector("#best-rank-count"),
  storageStatus: document.querySelector(".storage-status span"),
  chartKeyword: document.querySelector("#chart-keyword"),
  chartCanvas: document.querySelector("#rank-chart"),
  chartEmpty: document.querySelector("#chart-empty"),
  chartCurrent: document.querySelector("#chart-current"),
  chartBest: document.querySelector("#chart-best"),
  chartChange: document.querySelector("#chart-change"),
  chartRuns: document.querySelector("#chart-runs"),
  activityBody: document.querySelector("#activity-body"),
  activityEmpty: document.querySelector("#activity-empty"),
  exportReport: document.querySelector("#export-report"),
  exportCsv: document.querySelector("#export-csv"),
  printReport: document.querySelector("#print-report"),
  toast: document.querySelector("#toast")
};

function normalizePages(value) {
  return Math.max(1, Math.min(MAX_PAGES, Number.parseInt(value, 10) || DEFAULT_PAGES));
}

function rankLocation(rank) {
  if (!Number.isFinite(rank) || rank < 1) return null;
  return {
    page: Math.ceil(rank / 10),
    result: ((rank - 1) % 10) + 1,
    label: `Page ${Math.ceil(rank / 10)} · Result ${((rank - 1) % 10) + 1}`
  };
}

function populatePageSelect(select, selected = DEFAULT_PAGES) {
  select.replaceChildren();
  for (let page = 1; page <= MAX_PAGES; page += 1) {
    const option = document.createElement("option");
    option.value = String(page);
    option.textContent = `${page} page${page === 1 ? "" : "s"} · top ${page * 10}`;
    option.selected = page === normalizePages(selected);
    select.append(option);
  }
}

function normalizeWebsite(value) {
  const trimmed = value.trim();
  const candidate = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  const url = new URL(candidate);
  if (!url.hostname.includes(".") && url.hostname !== "localhost") throw new Error("Invalid domain");
  return {
    website: url.href.replace(/\/$/, ""),
    domain: url.hostname.toLowerCase().replace(/^www\./, "")
  };
}

async function saveTrackers() {
  await chrome.storage.local.set({ [STORAGE_KEY]: trackers });
  if (elements.storageStatus) elements.storageStatus.textContent = "Saved just now";
}

function showToast(message, type = "success") {
  clearTimeout(toastTimer);
  elements.toast.textContent = message;
  elements.toast.className = `toast show${type === "error" ? " error" : ""}`;
  toastTimer = setTimeout(() => { elements.toast.className = "toast"; }, 3400);
}

function formatTime(value) {
  if (!value) return "Not checked";
  return new Intl.DateTimeFormat(undefined, {
    month: "short", day: "numeric", hour: "numeric", minute: "2-digit"
  }).format(new Date(value));
}

function formatFullDate(value) {
  if (!value) return "—";
  return new Intl.DateTimeFormat(undefined, {
    year: "numeric", month: "short", day: "numeric", hour: "numeric", minute: "2-digit"
  }).format(new Date(value));
}

function formatShortDate(value) {
  if (!value) return "—";
  return new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric" }).format(new Date(value));
}

function movementBetween(previous, current) {
  if (previous === undefined) return { direction: "flat", label: "First check", csv: "First check" };
  if (current == null && previous != null) return { direction: "down", label: "Dropped out", csv: "Dropped out" };
  if (current != null && previous == null) return { direction: "up", label: "Back in", csv: "Back in range" };
  if (current == null && previous == null) return { direction: "flat", label: "Still out", csv: "Still outside range" };
  const change = previous - current;
  if (change > 0) return { direction: "up", label: `Up ${change}`, csv: `Up ${change}` };
  if (change < 0) return { direction: "down", label: `Down ${Math.abs(change)}`, csv: `Down ${Math.abs(change)}` };
  return { direction: "flat", label: "No change", csv: "No change" };
}

function getMovement(tracker) {
  const history = tracker.history || [];
  if (history.length < 2) return { direction: "flat", label: history.length ? "First check" : "Ready" };
  const current = history.at(-1).rank;
  const previous = history.at(-2).rank;
  return movementBetween(previous, current);
}

function getAllRuns() {
  return trackers.flatMap((tracker) => {
    const history = tracker.history || [];
    return history.map((entry, index) => ({
      tracker,
      entry,
      movement: movementBetween(index > 0 ? history[index - 1].rank : undefined, entry.rank),
      pages: normalizePages(entry.pages || tracker.pages)
    }));
  }).sort((a, b) => new Date(b.entry.checkedAt || 0) - new Date(a.entry.checkedAt || 0));
}

function createElement(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text != null) element.textContent = text;
  return element;
}

function populateChartKeywords() {
  if (!elements.chartKeyword) return null;
  const previousSelection = elements.chartKeyword.value;
  elements.chartKeyword.replaceChildren();

  if (!trackers.length) {
    const option = createElement("option", "", "No keywords yet");
    option.value = "";
    elements.chartKeyword.append(option);
    elements.chartKeyword.disabled = true;
    return null;
  }

  elements.chartKeyword.disabled = false;
  for (const tracker of trackers) {
    const option = createElement("option", "", `${tracker.keyword} · ${tracker.domain}`);
    option.value = tracker.id;
    elements.chartKeyword.append(option);
  }

  const preferred = trackers.find((tracker) => tracker.id === previousSelection)
    || trackers.find((tracker) => (tracker.history || []).length)
    || trackers[0];
  elements.chartKeyword.value = preferred.id;
  return preferred;
}

function drawRankChart(tracker) {
  if (!elements.chartCanvas || !elements.chartEmpty) return;
  const canvas = elements.chartCanvas;
  const history = (tracker?.history || [])
    .filter((entry) => entry.checkedAt)
    .sort((a, b) => new Date(a.checkedAt) - new Date(b.checkedAt));
  const hasData = history.length > 0;
  canvas.hidden = !hasData;
  elements.chartEmpty.classList.toggle("show", !hasData);

  if (!hasData) {
    elements.chartCurrent.textContent = "—";
    elements.chartBest.textContent = "—";
    elements.chartChange.textContent = "—";
    elements.chartChange.className = "";
    elements.chartRuns.textContent = "0";
    return;
  }

  const rect = canvas.parentElement.getBoundingClientRect();
  const width = Math.max(280, Math.floor(rect.width - 36));
  const height = 285;
  const ratio = Math.max(1, window.devicePixelRatio || 1);
  canvas.width = Math.floor(width * ratio);
  canvas.height = Math.floor(height * ratio);
  canvas.style.width = `${width}px`;
  canvas.style.height = `${height}px`;
  const context = canvas.getContext("2d");
  context.setTransform(ratio, 0, 0, ratio, 0, 0);
  context.clearRect(0, 0, width, height);

  const padding = { top: 22, right: 24, bottom: 42, left: 48 };
  const plotWidth = width - padding.left - padding.right;
  const plotHeight = height - padding.top - padding.bottom;
  const foundRanks = history.map((entry) => entry.rank).filter((rank) => Number.isFinite(rank));
  const configuredMax = normalizePages(tracker.pages) * 10;
  const maxRank = Math.max(10, configuredMax, ...foundRanks);
  const xFor = (index) => history.length === 1
    ? padding.left + (plotWidth / 2)
    : padding.left + ((index / (history.length - 1)) * plotWidth);
  const yFor = (rank) => {
    const value = rank == null ? maxRank : Math.max(1, Math.min(maxRank, rank));
    return padding.top + (((value - 1) / Math.max(1, maxRank - 1)) * plotHeight);
  };

  context.font = "11px Inter, Segoe UI, sans-serif";
  context.textBaseline = "middle";
  for (let index = 0; index < 4; index += 1) {
    const ratioPosition = index / 3;
    const y = padding.top + (ratioPosition * plotHeight);
    const label = Math.round(1 + (ratioPosition * (maxRank - 1)));
    context.beginPath();
    context.strokeStyle = "#dedbd4";
    context.lineWidth = 1;
    context.moveTo(padding.left, y);
    context.lineTo(width - padding.right, y);
    context.stroke();
    context.fillStyle = "#77736e";
    context.textAlign = "right";
    context.fillText(`#${label}`, padding.left - 9, y);
  }

  context.save();
  context.beginPath();
  history.forEach((entry, index) => {
    const x = xFor(index);
    const y = yFor(entry.rank);
    if (index === 0) context.moveTo(x, y);
    else context.lineTo(x, y);
  });
  context.strokeStyle = "#b4232d";
  context.lineWidth = 2.5;
  context.lineJoin = "round";
  context.lineCap = "round";
  context.stroke();
  context.restore();

  history.forEach((entry, index) => {
    const x = xFor(index);
    const y = yFor(entry.rank);
    context.beginPath();
    context.arc(x, y, entry.rank == null ? 5 : 4, 0, Math.PI * 2);
    context.fillStyle = entry.rank == null ? "#ffffff" : "#b4232d";
    context.fill();
    context.strokeStyle = entry.rank == null ? "#b4232d" : "#ffffff";
    context.lineWidth = 2;
    context.stroke();
  });

  const labelIndexes = [...new Set([0, Math.floor((history.length - 1) / 2), history.length - 1])];
  context.fillStyle = "#77736e";
  context.textBaseline = "top";
  labelIndexes.forEach((index, labelPosition) => {
    context.textAlign = labelPosition === 0 ? "left" : (labelPosition === labelIndexes.length - 1 ? "right" : "center");
    context.fillText(formatShortDate(history[index].checkedAt), xFor(index), height - padding.bottom + 14);
  });

  const latest = history.at(-1);
  const previous = history.length > 1 ? history.at(-2).rank : undefined;
  const movement = movementBetween(previous, latest.rank);
  const best = foundRanks.length ? Math.min(...foundRanks) : null;
  elements.chartCurrent.textContent = latest.rank == null ? `>${normalizePages(latest.pages || tracker.pages) * 10}` : `#${latest.rank}`;
  elements.chartBest.textContent = best == null ? "—" : `#${best}`;
  elements.chartChange.textContent = movement.label;
  elements.chartChange.className = movement.direction;
  elements.chartRuns.textContent = String(history.length);
  canvas.setAttribute("aria-label", `${tracker.keyword} ranking history with ${history.length} runs. Current ${elements.chartCurrent.textContent}, best ${elements.chartBest.textContent}, latest change ${movement.label}.`);
}

function renderActivity() {
  if (!elements.activityBody || !elements.activityEmpty) return;
  const runs = getAllRuns();
  elements.activityBody.replaceChildren();
  elements.activityEmpty.classList.toggle("show", runs.length === 0);

  for (const run of runs) {
    const row = document.createElement("tr");
    const dateCell = createElement("td", "run-date", formatFullDate(run.entry.checkedAt));
    const keywordCell = createElement("td", "run-keyword", run.tracker.keyword);
    const websiteCell = createElement("td", "", run.tracker.domain);
    const depthCell = createElement("td", "", `${run.pages} page${run.pages === 1 ? "" : "s"}`);
    const rankCell = createElement("td", "run-rank", run.entry.rank == null ? `>${run.pages * 10}` : `#${run.entry.rank}`);
    const locationCell = createElement("td", "run-location", rankLocation(run.entry.rank)?.label || "—");
    const changeCell = createElement("td", `run-change ${run.movement.direction}`, run.movement.label);
    row.append(dateCell, keywordCell, websiteCell, depthCell, rankCell, locationCell, changeCell);
    elements.activityBody.append(row);
  }
}

function renderDashboardDetails() {
  if (!elements.chartCanvas) return;
  const ranked = trackers.map((tracker) => tracker.rank).filter((rank) => Number.isFinite(rank));
  if (elements.bestRank) elements.bestRank.textContent = ranked.length ? `#${Math.min(...ranked)}` : "—";
  const selectedTracker = populateChartKeywords();
  drawRankChart(selectedTracker);
  renderActivity();
  const hasTrackers = trackers.length > 0;
  if (elements.exportReport) elements.exportReport.disabled = !hasTrackers;
  if (elements.exportCsv) elements.exportCsv.disabled = !hasTrackers;
}

function escapeCsv(value) {
  const text = String(value ?? "");
  return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  })[character]);
}

function downloadFile(contents, filename, type) {
  const blob = new Blob([contents], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function exportRows() {
  return trackers.flatMap((tracker) => {
    const history = tracker.history || [];
    if (!history.length) {
      return [{ tracker, entry: {}, movement: { csv: "Not checked" }, pages: normalizePages(tracker.pages) }];
    }
    return history.map((entry, index) => ({
      tracker,
      entry,
      movement: movementBetween(index > 0 ? history[index - 1].rank : undefined, entry.rank),
      pages: normalizePages(entry.pages || tracker.pages)
    }));
  });
}

function exportCsvReport() {
  const headers = [
    "Run date",
    "Keyword",
    "Website",
    "Pages checked",
    "Search range",
    "Rank",
    "Google page",
    "Result on page",
    "Change",
    "Ranked page title",
    "Ranked page domain",
    "Ranked page URL",
    "Google snippet"
  ];
  const rows = exportRows().map((run) => [
    run.entry.checkedAt ? formatFullDate(run.entry.checkedAt) : "Not checked",
    run.tracker.keyword,
    run.tracker.website,
    run.pages,
    `Top ${run.pages * 10}`,
    run.entry.checkedAt ? (run.entry.rank == null ? `Not found in top ${run.pages * 10}` : run.entry.rank) : "",
    run.entry.resultPageNumber || rankLocation(run.entry.rank)?.page || "",
    run.entry.resultPositionOnPage || rankLocation(run.entry.rank)?.result || "",
    run.movement.csv,
    run.entry.resultTitle || "",
    run.entry.resultDomain || "",
    run.entry.foundUrl || "",
    run.entry.resultSnippet || ""
  ]);
  const csv = `\uFEFF${[headers, ...rows].map((row) => row.map(escapeCsv).join(",")).join("\r\n")}`;
  const date = new Date().toISOString().slice(0, 10);
  downloadFile(csv, `toblerone-ranking-data-${date}.csv`, "text/csv;charset=utf-8");
  showToast("CSV exported for Excel or Google Sheets.");
}

function buildHtmlReport() {
  const runs = getAllRuns();
  const ranked = trackers.map((tracker) => tracker.rank).filter((rank) => Number.isFinite(rank));
  const topTen = trackers.filter((tracker) => tracker.rank && tracker.rank <= 10).length;
  const drops = trackers.filter((tracker) => getMovement(tracker).direction === "down").length;
  const chartImage = elements.chartCanvas && !elements.chartCanvas.hidden
    ? elements.chartCanvas.toDataURL("image/png")
    : "";

  const trackerRows = trackers.map((tracker) => {
    const movement = getMovement(tracker);
    const rank = tracker.lastCheckedAt
      ? (tracker.rank == null ? `Not found in top ${normalizePages(tracker.pages) * 10}` : `#${tracker.rank}`)
      : "Not checked";
    const location = rankLocation(tracker.rank)?.label || "—";
    const rankedPage = tracker.foundUrl
      ? `<a href="${escapeHtml(tracker.foundUrl)}">${escapeHtml(tracker.resultTitle || tracker.foundUrl)}</a><small>${escapeHtml(tracker.foundUrl)}</small>`
      : "—";
    return `<tr><td><strong>${escapeHtml(tracker.keyword)}</strong><small>${escapeHtml(tracker.domain)}</small></td><td>${escapeHtml(rank)}<small>${escapeHtml(location)}</small></td><td>${rankedPage}</td><td>${escapeHtml(movement.label)}</td><td>${escapeHtml(formatFullDate(tracker.lastCheckedAt))}</td></tr>`;
  }).join("");

  const runRows = runs.map((run) => {
    const rank = run.entry.rank == null ? `>${run.pages * 10}` : `#${run.entry.rank}`;
    const location = rankLocation(run.entry.rank)?.label || "—";
    const resultLink = run.entry.foundUrl
      ? `<a href="${escapeHtml(run.entry.foundUrl)}">${escapeHtml(run.entry.resultTitle || run.entry.foundUrl)}</a>`
      : "—";
    return `<tr><td>${escapeHtml(formatFullDate(run.entry.checkedAt))}</td><td>${escapeHtml(run.tracker.keyword)}</td><td>${escapeHtml(rank)}<small>${escapeHtml(location)}</small></td><td>${resultLink}</td><td>${escapeHtml(run.movement.label)}</td></tr>`;
  }).join("");

  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Toblerone SEO Ranking Report</title><style>
  :root{font-family:Inter,Arial,sans-serif;color:#171615;background:#f4f3ef}*{box-sizing:border-box}body{margin:0;padding:42px 24px}.report{max-width:1050px;margin:auto}.brand{display:flex;align-items:center;gap:12px;margin-bottom:38px}.mark{width:38px;height:38px;display:grid;place-items:center;background:#b4232d;color:white;font-weight:900}.brand strong{display:block}.brand span span{color:#77736e;font-size:12px}.hero{display:flex;justify-content:space-between;gap:30px;align-items:end;padding-bottom:28px;border-bottom:2px solid #171615}.hero h1{margin:0;font:500 46px Georgia,serif;letter-spacing:-2px}.hero p{max-width:380px;margin:0;color:#77736e;font-size:13px;line-height:1.5}.stats{display:grid;grid-template-columns:repeat(4,1fr);background:white;border:1px solid #dedbd4;margin:24px 0 34px}.stat{padding:18px;border-right:1px solid #dedbd4}.stat:last-child{border:0}.stat span{display:block;color:#77736e;font-size:10px;text-transform:uppercase}.stat strong{display:block;margin-top:5px;font:500 28px Georgia,serif}h2{margin:34px 0 12px;font-size:18px}table{width:100%;border-collapse:collapse;background:white;border:1px solid #dedbd4}th,td{padding:12px 14px;border-bottom:1px solid #ebe8e1;text-align:left;font-size:12px}th{color:#77736e;font-size:9px;text-transform:uppercase;letter-spacing:.08em}td small{display:block;margin-top:3px;color:#77736e}.chart{width:100%;padding:18px;background:white;border:1px solid #dedbd4}.chart img{display:block;width:100%;height:auto}.empty{padding:24px;background:white;color:#77736e;border:1px solid #dedbd4}.footer{margin-top:30px;color:#77736e;font-size:10px}@media(max-width:650px){.hero{display:block}.hero p{margin-top:16px}.stats{grid-template-columns:repeat(2,1fr)}.stat:nth-child(2){border-right:0}.hero h1{font-size:36px}table{display:block;overflow-x:auto;white-space:nowrap}}@media print{body{background:white;padding:0}.report{max-width:none}}
  </style></head><body><main class="report"><div class="brand"><div class="mark">T</div><span><strong>Toblerone</strong><span>SEO ranking report</span></span></div><section class="hero"><h1>Search visibility<br>report</h1><p>Generated ${escapeHtml(formatFullDate(new Date().toISOString()))}. Rankings reflect the Google result depth selected for each tracker.</p></section><section class="stats"><div class="stat"><span>Keywords</span><strong>${trackers.length}</strong></div><div class="stat"><span>Top 10</span><strong>${topTen}</strong></div><div class="stat"><span>Drops</span><strong>${drops}</strong></div><div class="stat"><span>Best rank</span><strong>${ranked.length ? `#${Math.min(...ranked)}` : "—"}</strong></div></section><h2>Current positions</h2><table><thead><tr><th>Keyword</th><th>Current rank</th><th>Ranked page</th><th>Latest change</th><th>Last checked</th></tr></thead><tbody>${trackerRows}</tbody></table>${chartImage ? `<h2>Selected keyword trend</h2><div class="chart"><img src="${chartImage}" alt="Ranking history chart"></div>` : ""}<h2>Run history</h2>${runs.length ? `<table><thead><tr><th>Date</th><th>Keyword</th><th>Rank</th><th>Ranked page</th><th>Change</th></tr></thead><tbody>${runRows}</tbody></table>` : `<div class="empty">No completed runs yet.</div>`}<p class="footer">Created with Toblerone Rank Tracker · Data exported from local browser storage.</p></main></body></html>`;
}

function exportShareableReport() {
  const date = new Date().toISOString().slice(0, 10);
  downloadFile(buildHtmlReport(), `toblerone-ranking-report-${date}.html`, "text/html;charset=utf-8");
  showToast("Shareable HTML report exported.");
}

function renderCard(tracker) {
  const pages = normalizePages(tracker.pages);
  const maxResults = pages * 10;
  const movement = getMovement(tracker);
  const card = createElement("article", "tracker-card");
  const main = createElement("div", "tracker-main");
  const identity = createElement("div");
  identity.append(createElement("h3", "keyword", tracker.keyword));
  identity.append(createElement("p", "domain", `${tracker.domain} · top ${maxResults}`));
  const rankBox = createElement("div", `rank-box ${movement.direction}`);
  rankBox.append(createElement("strong", "", tracker.rank == null ? "—" : `#${tracker.rank}`));
  rankBox.append(createElement(
    "small",
    "",
    tracker.rank == null && tracker.lastCheckedAt
      ? `Not in top ${maxResults}`
      : rankLocation(tracker.rank)?.label || "Current rank"
  ));
  main.append(identity, rankBox);

  const scale = createElement("div", "result-scale");
  const activePage = tracker.rank ? Math.ceil(tracker.rank / 10) : 0;
  for (let page = 1; page <= pages; page += 1) {
    const segmentClass = page === activePage ? "active" : (activePage && page < activePage ? "passed" : "");
    scale.append(createElement("span", segmentClass));
  }

  const footer = createElement("div", "tracker-footer");
  footer.append(createElement("span", `movement ${movement.direction}`, movement.label));
  const time = createElement("time", "", formatTime(tracker.lastCheckedAt));
  footer.append(time);
  const controls = createElement("div", "card-controls");
  const pageControl = createElement("label", "page-control");
  pageControl.append(createElement("span", "", "Pages"));
  const pageSelect = createElement("select");
  pageSelect.setAttribute("aria-label", `Pages to check for ${tracker.keyword}`);
  pageSelect.dataset.pagesFor = tracker.id;
  for (let page = 1; page <= MAX_PAGES; page += 1) {
    const option = createElement("option", "", String(page));
    option.value = String(page);
    option.selected = page === pages;
    pageSelect.append(option);
  }
  pageControl.append(pageSelect);
  const removeButton = createElement("button", "remove-button", "Remove");
  removeButton.type = "button";
  removeButton.dataset.remove = tracker.id;
  const runButton = createElement("button", "run-button", checkingIds.has(tracker.id) ? "Checking…" : "Check rank");
  runButton.type = "button";
  runButton.disabled = checkingIds.has(tracker.id);
  runButton.dataset.run = tracker.id;
  controls.append(pageControl, removeButton, runButton);
  footer.append(controls);

  card.append(main, scale);
  if (tracker.foundUrl) {
    const result = createElement("div", "ranked-result");
    const resultLink = createElement("a", "ranked-result-title", tracker.resultTitle || tracker.foundUrl);
    resultLink.href = tracker.foundUrl;
    resultLink.target = "_blank";
    resultLink.rel = "noreferrer";
    const resultUrl = createElement("div", "ranked-result-url", tracker.foundUrl);
    result.append(resultLink, resultUrl);
    if (tracker.resultSnippet) result.append(createElement("p", "ranked-result-snippet", tracker.resultSnippet));
    card.append(result);
  }
  card.append(footer);
  if ((tracker.history || []).length > 1) {
    const recent = tracker.history.slice(-3).map((entry) => {
      const rank = entry.rank == null ? `>${normalizePages(entry.pages || tracker.pages) * 10}` : `#${entry.rank}`;
      return `${formatShortDate(entry.checkedAt)} · ${rank}`;
    }).join("  /  ");
    card.append(createElement("p", "history-line", `Recent runs  ${recent}`));
  }
  return card;
}

function render() {
  elements.list.replaceChildren(...trackers.map(renderCard));
  elements.empty.classList.toggle("show", trackers.length === 0);
  elements.checkAll.disabled = trackers.length === 0 || checkingIds.size > 0;
  elements.checkAll.textContent = checkingIds.size ? "Checking…" : (document.body.dataset.view === "dashboard" ? "Check all keywords" : "Check all");
  elements.total.textContent = String(trackers.length);
  elements.topTen.textContent = String(trackers.filter((item) => item.rank && item.rank <= 10).length);
  elements.warnings.textContent = String(trackers.filter((item) => getMovement(item).direction === "down").length);
  renderDashboardDetails();
}

async function checkTracker(id, quiet = false) {
  const tracker = trackers.find((item) => item.id === id);
  if (!tracker || checkingIds.has(id)) return;
  checkingIds.add(id);
  render();

  try {
    const result = await chrome.runtime.sendMessage({
      target: "background",
      type: "CHECK_RANK",
      keyword: tracker.keyword,
      website: tracker.website,
      pages: normalizePages(tracker.pages)
    });
    if (!result?.ok) throw new Error(result?.error || "Ranking check failed.");
    tracker.rank = result.rank;
    tracker.lastCheckedAt = result.checkedAt;
    tracker.foundUrl = result.foundUrl;
    tracker.resultTitle = result.resultTitle;
    tracker.resultSnippet = result.resultSnippet;
    tracker.resultDomain = result.resultDomain;
    tracker.resultPageNumber = result.resultPageNumber;
    tracker.resultPositionOnPage = result.resultPositionOnPage;
    const historyEntry = {
      id: crypto.randomUUID(),
      rank: result.rank,
      checkedAt: result.checkedAt,
      foundUrl: result.foundUrl,
      resultTitle: result.resultTitle,
      resultSnippet: result.resultSnippet,
      resultDomain: result.resultDomain,
      resultPageNumber: result.resultPageNumber,
      resultPositionOnPage: result.resultPositionOnPage,
      pages: normalizePages(tracker.pages)
    };
    tracker.history = [...(tracker.history || []), historyEntry].slice(-365);
    await saveTrackers();
    const syncResult = await chrome.runtime.sendMessage({
      target: "background",
      type: "SYNC_RUN",
      tracker,
      entry: historyEntry
    }).catch(() => ({ ok: false }));
    if (elements.storageStatus) {
      elements.storageStatus.textContent = syncResult?.ok ? "Saved locally · synced to web" : "Saved locally · web sync pending";
    }
    if (!quiet) {
      const location = rankLocation(result.rank)?.label;
      showToast(result.rank ? `${tracker.domain} is ranking at #${result.rank} · ${location}.` : `${tracker.domain} was not found in the top ${normalizePages(tracker.pages) * 10}.`);
    }
  } catch (error) {
    showToast(error?.message || "Could not check this keyword.", "error");
  } finally {
    checkingIds.delete(id);
    render();
  }
}

elements.form.addEventListener("submit", async (event) => {
  event.preventDefault();
  elements.formError.textContent = "";
  const keyword = elements.keyword.value.trim();
  try {
    const chosenSite = elements.siteSelect && elements.siteSelect.value !== "__other" ? elements.siteSelect.value : "";
    if (elements.siteSelect && !chosenSite && elements.siteSelect.value !== "__other") throw new Error("Choose a website.");
    const normalized = normalizeWebsite(chosenSite || elements.website.value);
    const duplicate = trackers.some((item) => item.keyword.toLowerCase() === keyword.toLowerCase() && item.domain === normalized.domain);
    if (duplicate) throw new Error("This keyword and website are already being tracked.");
    trackers.unshift({
      id: crypto.randomUUID(),
      keyword,
      website: normalized.website,
      domain: normalized.domain,
      pages: normalizePages(elements.pages.value),
      rank: null,
      lastCheckedAt: null,
      foundUrl: null,
      resultTitle: null,
      resultSnippet: null,
      resultDomain: null,
      resultPageNumber: null,
      resultPositionOnPage: null,
      history: []
    });
    await saveTrackers();
    const keepSite = elements.siteSelect?.value;
    elements.form.reset();
    if (elements.siteSelect && keepSite) elements.siteSelect.value = keepSite;
    populatePageSelect(elements.pages, DEFAULT_PAGES);
    render();
    showToast("Tracker added. Run a check when you’re ready.");
  } catch (error) {
    elements.formError.textContent = error?.message === "Invalid domain" ? "Enter a valid website, for example example.com." : error.message;
  }
});

elements.list.addEventListener("change", async (event) => {
  const pageSelect = event.target.closest("[data-pages-for]");
  if (!pageSelect) return;
  const tracker = trackers.find((item) => item.id === pageSelect.dataset.pagesFor);
  if (!tracker) return;
  tracker.pages = normalizePages(pageSelect.value);
  await saveTrackers();
  render();
});

elements.list.addEventListener("click", async (event) => {
  const runButton = event.target.closest("[data-run]");
  if (runButton) return checkTracker(runButton.dataset.run);
  const removeButton = event.target.closest("[data-remove]");
  if (removeButton) {
    trackers = trackers.filter((item) => item.id !== removeButton.dataset.remove);
    await saveTrackers();
    render();
    showToast("Tracker removed.");
  }
});

elements.checkAll.addEventListener("click", async () => {
  for (const tracker of [...trackers]) await checkTracker(tracker.id, true);
  showToast("All keyword checks are complete.");
});

elements.openDashboard?.addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ target: "background", type: "OPEN_DASHBOARD" });
});

elements.chartKeyword?.addEventListener("change", () => {
  const tracker = trackers.find((item) => item.id === elements.chartKeyword.value);
  drawRankChart(tracker);
});

elements.exportCsv?.addEventListener("click", exportCsvReport);
elements.exportReport?.addEventListener("click", exportShareableReport);
elements.printReport?.addEventListener("click", () => window.print());

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local" || !changes[STORAGE_KEY]) return;
  const nextValue = changes[STORAGE_KEY].newValue;
  trackers = Array.isArray(nextValue)
    ? nextValue.map((tracker) => ({ ...tracker, pages: normalizePages(tracker.pages) }))
    : [];
  render();
});

async function loadSites() {
  if (!elements.siteSelect) return;
  const response = await chrome.runtime.sendMessage({ target: "background", type: "GET_SITES" }).catch(() => null);
  const sites = [...new Set([...(response?.sites || []), ...trackers.map((tracker) => tracker.domain)])].sort();
  const current = elements.siteSelect.value;
  elements.siteSelect.innerHTML = "";
  const placeholder = createElement("option", "", sites.length ? "Choose a website" : "No sites yet — add one");
  placeholder.value = "";
  elements.siteSelect.append(placeholder);
  for (const site of sites) {
    const option = createElement("option", "", site);
    option.value = site;
    elements.siteSelect.append(option);
  }
  const other = createElement("option", "", "Other website…");
  other.value = "__other";
  elements.siteSelect.append(other);
  if (current && [...elements.siteSelect.options].some((o) => o.value === current)) elements.siteSelect.value = current;
  toggleWebsiteInput();
}

function toggleWebsiteInput() {
  const other = elements.siteSelect?.value === "__other";
  if (elements.websiteWrap) elements.websiteWrap.hidden = !other;
  if (elements.website) elements.website.required = Boolean(other);
}

elements.siteSelect?.addEventListener("change", toggleWebsiteInput);

async function initialize() {
  populatePageSelect(elements.pages, DEFAULT_PAGES);
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  trackers = Array.isArray(stored[STORAGE_KEY])
    ? stored[STORAGE_KEY].map((tracker) => ({ ...tracker, pages: normalizePages(tracker.pages) }))
    : [];
  const connection = await chrome.runtime.sendMessage({ target: "background", type: "GET_CONNECTION_STATUS" }).catch(() => null);
  if (elements.openDashboard) {
    elements.openDashboard.textContent = connection?.connected ? "Open web dashboard" : "Connect dashboard";
  }
  if (elements.storageStatus) {
    elements.storageStatus.textContent = connection?.connected ? "Connected to web dashboard" : "Saved locally · dashboard not connected";
  }
  render();
  loadSites();
  if (elements.chartCanvas && "ResizeObserver" in window) {
    chartResizeObserver = new ResizeObserver(() => {
      const tracker = trackers.find((item) => item.id === elements.chartKeyword?.value);
      if (tracker) requestAnimationFrame(() => drawRankChart(tracker));
    });
    chartResizeObserver.observe(elements.chartCanvas.parentElement);
  }
}

initialize().catch(() => showToast("Could not load saved trackers.", "error"));

  const configForm = document.querySelector("#config-form");
  if (configForm) {
    const urlInput = document.querySelector("#dashboard-url");
    const submitButton = configForm.querySelector("button[type='submit']");
    if (urlInput && !urlInput.value.trim()) {
      urlInput.value = "https://toblerone-refine-cloud.lovable.app";
    }
    configForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const input = urlInput.value.trim();
      const errEl = document.querySelector("#config-error");
      errEl.textContent = "";
      errEl.style.display = "none";
      const originalLabel = submitButton ? submitButton.textContent : "";
      if (submitButton) {
        submitButton.disabled = true;
        submitButton.textContent = "Connecting…";
      }
      try {
        const result = await chrome.runtime.sendMessage({
          target: "background",
          type: "CONNECT_WITH_URL",
          dashboardUrl: input
        });
        if (!result?.ok) throw new Error(result?.error || "Could not connect to this dashboard.");
        const synced = Number(result.syncedRuns || 0);
        showToast(synced ? `Connected · ${synced} run${synced === 1 ? "" : "s"} synced` : "Connected to dashboard", "success");
        if (elements.storageStatus) elements.storageStatus.textContent = "Connected to web dashboard";
        if (elements.openDashboard) elements.openDashboard.textContent = "Open web dashboard";
      } catch (err) {
        errEl.textContent = err.message;
        errEl.style.display = "block";
      } finally {
        if (submitButton) {
          submitButton.disabled = false;
          submitButton.textContent = originalLabel || "Save & Connect";
        }
      }
    });
  }