"use strict";

/* ------------------------------------------------------------------ *
 * Page Index Verifier
 *
 * Three checking methods:
 *   1. "gsc"    Google Search Console URL Inspection API (OAuth).
 *               Official, no CAPTCHA, real index status + reason.
 *               Works only on properties verified in your Search Console.
 *   2. "bing"   Bing Webmaster Tools GetUrlInfo API (API key).
 *               No CAPTCHA. Works only on your verified Bing sites.
 *   3. "scrape" Google `site:` search scraping. Any URL, but Google
 *               shows CAPTCHAs; the run auto-pauses so you can solve one.
 * ------------------------------------------------------------------ */

const $ = (id) => document.getElementById(id);

const el = {
  urls: $("urls"),
  fileInput: $("fileInput"),
  loadBtn: $("loadBtn"),
  clearBtn: $("clearBtn"),
  method: $("method"),
  // gsc
  gscClientId: $("gscClientId"),
  gscRedirect: $("gscRedirect"),
  gscCopyRedirect: $("gscCopyRedirect"),
  gscConnectBtn: $("gscConnectBtn"),
  gscDisconnectBtn: $("gscDisconnectBtn"),
  gscDot: $("gscDot"),
  gscStatusText: $("gscStatusText"),
  gscProps: $("gscProps"),
  // bing
  bingApiKey: $("bingApiKey"),
  bingVerifyBtn: $("bingVerifyBtn"),
  bingClearBtn: $("bingClearBtn"),
  bingDot: $("bingDot"),
  bingStatusText: $("bingStatusText"),
  bingProps: $("bingProps"),
  // scrape
  region: $("region"),
  matchMode: $("matchMode"),
  adaptive: $("adaptive"),
  // speed
  minDelay: $("minDelay"),
  maxDelay: $("maxDelay"),
  concurrency: $("concurrency"),
  speedHint: $("speedHint"),
  // run
  startBtn: $("startBtn"),
  stopBtn: $("stopBtn"),
  recheckBtn: $("recheckBtn"),
  runStatus: $("runStatus"),
  progressBar: $("progressBar"),
  filterInput: $("filterInput"),
  statusFilter: $("statusFilter"),
  copyBtn: $("copyBtn"),
  exportCsvBtn: $("exportCsvBtn"),
  tbody: $("tbody"),
  emptyState: $("emptyState"),
  cTotal: $("cTotal"),
  cIndexed: $("cIndexed"),
  cNot: $("cNot"),
  cErr: $("cErr"),
};

const REGION_DOMAIN = { us: "com", uk: "co.uk", ca: "ca", au: "com.au", in: "co.in" };
const REGION_GL = { us: "us", uk: "uk", ca: "ca", au: "au", in: "in" };

/** @typedef {{url:string, status:string, detail:string, checkedAt:number|null}} Row */
/** @type {Row[]} */
let rows = [];
let running = false;
let stopRequested = false;
let paused = false;

// Auth / connection state
let gscToken = null;
let gscTokenExpiry = 0;
let gscProperties = [];   // array of siteUrl strings
let bingSites = [];       // array of site url strings

/* ----------------------------- Persistence ----------------------------- */

function saveState() {
  chrome.storage.local.set({
    piv_rows: rows,
    piv_settings: {
      method: el.method.value,
      minDelay: el.minDelay.value,
      maxDelay: el.maxDelay.value,
      region: el.region.value,
      matchMode: el.matchMode.value,
      adaptive: el.adaptive.checked,
      concurrency: el.concurrency.value,
      draft: el.urls.value,
      gscClientId: el.gscClientId.value.trim(),
      bingApiKey: el.bingApiKey.value.trim(),
    },
    piv_auth: { gscToken, gscTokenExpiry, gscProperties, bingSites },
  });
}

function loadState() {
  el.gscRedirect.textContent = chrome.identity.getRedirectURL();
  chrome.storage.local.get(["piv_rows", "piv_settings", "piv_auth"], (data) => {
    const s = data.piv_settings || {};
    if (s.method) el.method.value = s.method;
    if (s.minDelay != null) el.minDelay.value = s.minDelay;
    if (s.maxDelay != null) el.maxDelay.value = s.maxDelay;
    if (s.region) el.region.value = s.region;
    if (s.matchMode) el.matchMode.value = s.matchMode;
    if (s.adaptive != null) el.adaptive.checked = s.adaptive;
    if (s.concurrency) el.concurrency.value = s.concurrency;
    if (s.draft) el.urls.value = s.draft;
    if (s.gscClientId) el.gscClientId.value = s.gscClientId;
    if (s.bingApiKey) el.bingApiKey.value = s.bingApiKey;

    const a = data.piv_auth || {};
    gscToken = a.gscToken || null;
    gscTokenExpiry = a.gscTokenExpiry || 0;
    gscProperties = a.gscProperties || [];
    bingSites = a.bingSites || [];

    if (Array.isArray(data.piv_rows)) {
      rows = data.piv_rows.map((r) => ({
        url: r.url,
        status: r.status === "CHECKING" ? "PENDING" : r.status,
        detail: r.detail || "",
        checkedAt: r.checkedAt || null,
      }));
    }
    applyMethodUI();
    refreshGscStatus();
    refreshBingStatus();
    renderTable();
    updateCounts();
  });
}

/* ----------------------------- Method UI ----------------------------- */

function applyMethodUI() {
  const m = el.method.value;
  $("cfg-gsc").hidden = m !== "gsc";
  $("cfg-bing").hidden = m !== "bing";
  $("cfg-scrape").hidden = m !== "scrape";
  el.speedHint.textContent = m === "scrape"
    ? "Scraping needs delays to avoid CAPTCHAs. 1–2s min is a good start."
    : "This API has no CAPTCHA — you can set delay to 0 and concurrency to 5.";
}

el.method.addEventListener("change", () => { applyMethodUI(); saveState(); });

document.querySelectorAll(".setup-toggle").forEach((a) => {
  a.addEventListener("click", (e) => {
    e.preventDefault();
    const box = $(a.dataset.target);
    box.hidden = !box.hidden;
    a.textContent = a.textContent.replace(box.hidden ? "▴" : "▾", box.hidden ? "▾" : "▴");
  });
});

/* ----------------------------- URL helpers ----------------------------- */

function normalizeInputUrl(raw) {
  let u = (raw || "").trim();
  if (!u) return null;
  u = u.replace(/^["'\s,;-]+|["'\s,;]+$/g, "");
  if (!u) return null;
  if (!/^https?:\/\//i.test(u)) u = "https://" + u;
  try { return new URL(u).href; } catch { return null; }
}

function parseLinesToUrls(text) {
  const out = [], seen = new Set();
  for (const line of String(text).split(/[\r\n]+/)) {
    const n = normalizeInputUrl(line);
    if (n && !seen.has(n)) { seen.add(n); out.push(n); }
  }
  return out;
}

/* Split pasted text into one token per line. Links separated by spaces, tabs,
   commas, semicolons, pipes or newlines each end up on their own line. The
   tokens are left exactly as pasted (not normalized) — loadIntoTable handles
   normalization later, so the user keeps seeing the URLs they pasted. */
function splitPastedLinks(text) {
  return String(text)
    .split(/[\s,;|]+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

/* ----------------------------- File import ----------------------------- */

el.fileInput.addEventListener("change", async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const name = file.name.toLowerCase();
  try {
    if (name.endsWith(".xlsx") || name.endsWith(".xls")) await importSpreadsheet(file);
    else importDelimited(await file.text());
  } catch (err) {
    alert("Could not read file: " + err.message);
  } finally {
    el.fileInput.value = "";
  }
});

function importDelimited(text) {
  const found = [];
  for (const line of text.split(/[\r\n]+/))
    for (const cell of line.split(/[,\t;]/)) {
      const n = normalizeInputUrl(cell);
      if (n) found.push(n);
    }
  mergeIntoTextarea(found);
}

async function importSpreadsheet(file) {
  if (typeof XLSX === "undefined") {
    alert("XLSX library missing. Use CSV, or re-add vendor/xlsx.full.min.js.");
    return;
  }
  const wb = XLSX.read(await file.arrayBuffer(), { type: "array" });
  const found = [];
  for (const sheetName of wb.SheetNames) {
    const aoa = XLSX.utils.sheet_to_json(wb.Sheets[sheetName], { header: 1, blankrows: false });
    for (const r of aoa) for (const cell of r) {
      const n = normalizeInputUrl(String(cell));
      if (n) found.push(n);
    }
  }
  mergeIntoTextarea(found);
}

function mergeIntoTextarea(urls) {
  if (!urls.length) { alert("No URLs found in that file."); return; }
  const existing = el.urls.value.trim();
  el.urls.value = (existing ? existing + "\n" : "") + urls.join("\n");
  saveState();
  loadIntoTable();
}

/* ----------------------------- Table load ----------------------------- */

function loadIntoTable() {
  const urls = parseLinesToUrls(el.urls.value);
  const byUrl = new Map(rows.map((r) => [r.url, r]));
  rows = urls.map((u) => byUrl.get(u) || { url: u, status: "PENDING", detail: "", checkedAt: null });
  renderTable();
  updateCounts();
  saveState();
}

el.loadBtn.addEventListener("click", loadIntoTable);

el.clearBtn.addEventListener("click", () => {
  if (running) return;
  if (!confirm("Clear all links and results?")) return;
  el.urls.value = "";
  rows = [];
  renderTable();
  updateCounts();
  saveState();
});

/* ----------------------------- Rendering ----------------------------- */

const STATUS_LABEL = {
  INDEXED: "Indexed", NOT_INDEXED: "Not indexed", ERROR: "Error",
  PENDING: "Pending", CHECKING: "Checking…",
};

function badge(status) {
  return `<span class="badge b-${status}">${STATUS_LABEL[status] || status}</span>`;
}

function passesFilter(r) {
  const text = el.filterInput.value.trim().toLowerCase();
  const sf = el.statusFilter.value;
  if (text && !r.url.toLowerCase().includes(text)) return false;
  if (sf !== "all") {
    if (sf === "PENDING") return r.status === "PENDING" || r.status === "CHECKING";
    return r.status === sf;
  }
  return true;
}

function renderTable() {
  const frag = document.createDocumentFragment();
  let shown = 0;
  rows.forEach((r, i) => {
    if (!passesFilter(r)) return;
    shown++;
    const tr = document.createElement("tr");
    tr.dataset.url = r.url;
    tr.innerHTML =
      `<td class="col-num">${i + 1}</td>` +
      `<td class="url-cell"><a href="${escapeHtml(r.url)}" target="_blank" rel="noopener">${escapeHtml(r.url)}</a></td>` +
      `<td class="col-status">${badge(r.status)}</td>` +
      `<td class="detail-cell">${escapeHtml(r.detail || "")}</td>` +
      `<td class="col-action"><a class="open-link" target="_blank" rel="noopener" title="Open Google site: search" href="${googleSearchUrl(r.url)}">↗</a></td>`;
    frag.appendChild(tr);
  });
  el.tbody.replaceChildren(frag);
  el.emptyState.style.display = rows.length && shown ? "none" : "block";
  if (!rows.length) el.emptyState.textContent = "No links loaded yet. Paste links or import a file, then Load into table.";
  else if (!shown) el.emptyState.textContent = "No rows match the current filter.";
}

function updateRowInPlace(r) {
  const tr = el.tbody.querySelector(`tr[data-url="${cssEscape(r.url)}"]`);
  if (!tr) { renderTable(); return; }
  tr.querySelector(".col-status").innerHTML = badge(r.status);
  tr.querySelector(".detail-cell").textContent = r.detail || "";
}

function updateCounts() {
  let indexed = 0, not = 0, err = 0;
  for (const r of rows) {
    if (r.status === "INDEXED") indexed++;
    else if (r.status === "NOT_INDEXED") not++;
    else if (r.status === "ERROR") err++;
  }
  el.cTotal.textContent = rows.length;
  el.cIndexed.textContent = indexed;
  el.cNot.textContent = not;
  el.cErr.textContent = err;
  const done = rows.filter((r) => r.status !== "PENDING" && r.status !== "CHECKING").length;
  el.progressBar.style.width = rows.length ? (100 * done) / rows.length + "%" : "0%";
  if (!running) el.recheckBtn.disabled = !rows.some((r) => r.status === "ERROR");
}

el.filterInput.addEventListener("input", renderTable);
el.statusFilter.addEventListener("change", renderTable);

/* =====================================================================
 * METHOD 1 — Google Search Console URL Inspection API
 * ===================================================================== */

function refreshGscStatus() {
  const connected = !!gscToken && gscTokenExpiry > Date.now();
  el.gscDot.className = "dot" + (connected ? " ok" : gscToken ? " busy" : "");
  el.gscStatusText.textContent = connected
    ? "Connected" : gscToken ? "Token expired — click Connect" : "Not connected";
  el.gscDisconnectBtn.disabled = !gscToken;
  el.gscProps.textContent = gscProperties.length
    ? `${gscProperties.length} verified propert${gscProperties.length === 1 ? "y" : "ies"} found.`
    : "";
}

async function gscAuthorize(interactive) {
  const clientId = el.gscClientId.value.trim();
  if (!clientId) throw new Error("Enter your OAuth Client ID first.");
  const redirectUri = chrome.identity.getRedirectURL();
  const scope = "https://www.googleapis.com/auth/webmasters.readonly";
  const authUrl = "https://accounts.google.com/o/oauth2/v2/auth" +
    "?client_id=" + encodeURIComponent(clientId) +
    "&response_type=token" +
    "&redirect_uri=" + encodeURIComponent(redirectUri) +
    "&scope=" + encodeURIComponent(scope) +
    (interactive ? "&prompt=consent" : "");
  const resultUrl = await chrome.identity.launchWebAuthFlow({ url: authUrl, interactive });
  if (!resultUrl) throw new Error("Authorization was cancelled.");
  const frag = resultUrl.split("#")[1] || "";
  const params = new URLSearchParams(frag);
  const token = params.get("access_token");
  if (!token) throw new Error(params.get("error") || "No access token returned.");
  gscToken = token;
  gscTokenExpiry = Date.now() + (parseInt(params.get("expires_in") || "3600", 10) * 1000) - 60000;
}

async function gscEnsureToken() {
  if (gscToken && gscTokenExpiry > Date.now()) return;
  try { await gscAuthorize(false); }        // silent refresh
  catch { await gscAuthorize(true); }       // fall back to interactive
}

async function gscApi(url, opts) {
  await gscEnsureToken();
  const resp = await fetch(url, {
    ...opts,
    headers: { ...(opts && opts.headers), Authorization: "Bearer " + gscToken },
  });
  return resp;
}

async function gscLoadProperties() {
  const resp = await gscApi("https://searchconsole.googleapis.com/webmasters/v3/sites");
  if (!resp.ok) throw new Error("Sites list failed: HTTP " + resp.status);
  const data = await resp.json();
  gscProperties = (data.siteEntry || [])
    .filter((s) => s.permissionLevel && s.permissionLevel !== "siteUnverifiedUser")
    .map((s) => s.siteUrl);
}

function matchGscProperty(url) {
  let host = "";
  try { host = new URL(url).host; } catch { return null; }
  let best = null, bestLen = -1;
  for (const p of gscProperties) {
    if (p.startsWith("sc-domain:")) {
      const d = p.slice(10);
      if (host === d || host.endsWith("." + d)) { if (d.length > bestLen) { best = p; bestLen = d.length; } }
    } else if (url.startsWith(p) || (url + "/").startsWith(p)) {
      if (p.length > bestLen) { best = p; bestLen = p.length; }
    }
  }
  return best;
}

async function gscCheck(url) {
  const siteUrl = matchGscProperty(url);
  if (!siteUrl) return { status: "ERROR", detail: "No matching Search Console property" };
  const resp = await gscApi("https://searchconsole.googleapis.com/v1/urlInspection/index:inspect", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ inspectionUrl: url, siteUrl }),
  });
  if (resp.status === 401) { gscToken = null; return { status: "ERROR", detail: "Auth expired — click Connect again" }; }
  if (resp.status === 403) return { status: "ERROR", detail: "403 Forbidden — property not verified or no permission" };
  if (resp.status === 429) return { status: "ERROR", detail: "429 Quota exceeded — try again later" };
  if (!resp.ok) {
    let msg = "HTTP " + resp.status;
    try { const j = await resp.json(); if (j.error && j.error.message) msg = j.error.message; } catch {}
    return { status: "ERROR", detail: msg.slice(0, 120) };
  }
  const data = await resp.json();
  if (!data.inspectionResult) return { status: "ERROR", detail: "No inspection result returned by Google" };
  const r = data.inspectionResult.indexStatusResult || {};
  const coverage = r.coverageState || "Unknown";

  // A failed page fetch (robots block, 404, 5xx, redirect error, …) is a real
  // problem, not a plain "not indexed". Surface it as an error with a readable
  // description so the user knows WHY the page can't be indexed.
  const fetchState = r.pageFetchState;
  if (fetchState && fetchState !== "SUCCESSFUL" && fetchState !== "PAGE_FETCH_STATE_UNSPECIFIED") {
    const label = GSC_FETCH_ERRORS[fetchState] || fetchState.replace(/_/g, " ").toLowerCase();
    return { status: "ERROR", detail: coverage && coverage !== "Unknown" ? `${label} — ${coverage}` : label };
  }

  const indexed = r.verdict === "PASS" || (/(^|\s)indexed/i.test(coverage) && !/not indexed/i.test(coverage));
  return { status: indexed ? "INDEXED" : "NOT_INDEXED", detail: coverage };
}

/* Human-readable descriptions for Google's pageFetchState error values. */
const GSC_FETCH_ERRORS = {
  SOFT_404: "Soft 404 — page looks empty/missing to Google",
  BLOCKED_ROBOTS_TXT: "Blocked by robots.txt",
  NOT_FOUND: "404 Not Found",
  ACCESS_DENIED: "401 Access denied (sign-in required)",
  ACCESS_FORBIDDEN: "403 Access forbidden",
  SERVER_ERROR: "5xx Server error",
  REDIRECT_ERROR: "Redirect error (loop or broken redirect)",
  BLOCKED_4XX: "Blocked by a 4xx error",
  INTERNAL_CRAWL_ERROR: "Google internal crawl error",
  INVALID_URL: "Invalid URL",
};

el.gscCopyRedirect.addEventListener("click", async () => {
  await copyText(chrome.identity.getRedirectURL());
  el.gscCopyRedirect.textContent = "Copied";
  setTimeout(() => (el.gscCopyRedirect.textContent = "Copy"), 1200);
});

el.gscConnectBtn.addEventListener("click", async () => {
  el.gscConnectBtn.disabled = true;
  el.gscStatusText.textContent = "Connecting…";
  try {
    await gscAuthorize(true);
    await gscLoadProperties();
    saveState();
  } catch (err) {
    alert("Google connection failed:\n" + err.message);
  } finally {
    el.gscConnectBtn.disabled = false;
    refreshGscStatus();
  }
});

el.gscDisconnectBtn.addEventListener("click", () => {
  gscToken = null; gscTokenExpiry = 0; gscProperties = [];
  saveState(); refreshGscStatus();
});

/* =====================================================================
 * METHOD 2 — Bing Webmaster Tools (GetUrlInfo)
 * ===================================================================== */

function bingBase(method) {
  return "https://ssl.bing.com/webmaster/api.svc/json/" + method +
    "?apikey=" + encodeURIComponent(el.bingApiKey.value.trim());
}

function refreshBingStatus() {
  const has = !!el.bingApiKey.value.trim();
  const ok = bingSites.length > 0;
  el.bingDot.className = "dot" + (ok ? " ok" : has ? " busy" : "");
  el.bingStatusText.textContent = ok ? "Verified" : has ? "Key entered — click Verify" : "No key";
  el.bingClearBtn.disabled = !has;
  el.bingProps.textContent = bingSites.length
    ? `${bingSites.length} verified site${bingSites.length === 1 ? "" : "s"} found.`
    : "";
}

async function bingLoadSites() {
  const resp = await fetch(bingBase("GetUserSites"));
  if (!resp.ok) throw new Error("HTTP " + resp.status + " — check the API key.");
  const data = await resp.json();
  const arr = (data.d && (data.d.Sites || data.d)) || [];
  bingSites = arr.map((s) => s.Url || s.url).filter(Boolean);
  if (!bingSites.length) throw new Error("Key works but no verified sites found in Bing Webmaster Tools.");
}

function matchBingSite(url) {
  let host = "";
  try { host = new URL(url).host; } catch { return null; }
  let best = null, bestLen = -1;
  for (const site of bingSites) {
    let sh = "";
    try { sh = new URL(site).host; } catch { continue; }
    if (host === sh || host.endsWith("." + sh)) { if (sh.length > bestLen) { best = site; bestLen = sh.length; } }
  }
  return best || (bingSites.length === 1 ? bingSites[0] : null);
}

function parseMsDate(v) {
  const m = /\/Date\((\d+)/.exec(String(v || ""));
  return m ? new Date(+m[1]).toISOString().slice(0, 10) : "";
}

async function bingCheck(url) {
  const siteUrl = matchBingSite(url);
  if (!siteUrl) return { status: "ERROR", detail: "No matching Bing site" };
  const api = bingBase("GetUrlInfo") + "&siteUrl=" + encodeURIComponent(siteUrl) + "&url=" + encodeURIComponent(url);
  const resp = await fetch(api);
  if (resp.status === 401 || resp.status === 403) return { status: "ERROR", detail: `${resp.status} Forbidden — check API key` };
  if (resp.status === 429) return { status: "ERROR", detail: "429 Rate limited — slow down" };
  if (!resp.ok) return { status: "ERROR", detail: "HTTP " + resp.status };
  const data = await resp.json();
  const info = data.d;
  if (!info) return { status: "NOT_INDEXED", detail: "Unknown to Bing" };

  // An HTTP error on the page itself is a real problem, not a plain
  // "not indexed" — describe it so the user can act on it.
  if (info.HttpStatus != null && info.HttpStatus >= 400) {
    return { status: "ERROR", detail: `Page returns HTTP ${info.HttpStatus} — fix before it can be indexed` };
  }

  const crawled = parseMsDate(info.LastCrawledDate);
  const httpOk = info.HttpStatus == null || info.HttpStatus === 200;
  const indexed = !!crawled && httpOk;
  return {
    status: indexed ? "INDEXED" : "NOT_INDEXED",
    detail: crawled ? "Crawled " + crawled : (info.HttpStatus ? "HTTP " + info.HttpStatus : "Not crawled"),
  };
}

el.bingVerifyBtn.addEventListener("click", async () => {
  el.bingVerifyBtn.disabled = true;
  el.bingStatusText.textContent = "Verifying…";
  try { await bingLoadSites(); saveState(); }
  catch (err) { bingSites = []; alert("Bing verification failed:\n" + err.message); }
  finally { el.bingVerifyBtn.disabled = false; refreshBingStatus(); }
});

el.bingClearBtn.addEventListener("click", () => {
  el.bingApiKey.value = ""; bingSites = [];
  saveState(); refreshBingStatus();
});

/* =====================================================================
 * METHOD 3 — Google search scraping
 * ===================================================================== */

function googleDomain() { return REGION_DOMAIN[el.region.value] || "com"; }

function googleSearchUrl(url) {
  const q = el.matchMode.value === "loose"
    ? "site:" + url.replace(/^https?:\/\//i, "")
    : "site:" + url;
  const gl = REGION_GL[el.region.value] || "us";
  return `https://www.google.${googleDomain()}/search?q=${encodeURIComponent(q)}&num=10&hl=en&gl=${gl}&pws=0`;
}

/* extractGoogleResult — runs INSIDE the real Google tab via chrome.scripting.
   Receives the full rendered DOM, which is why this massively reduces CAPTCHAs:
   real navigation headers, full cookie jar, JS execution, browser fingerprint. */
function extractGoogleResult(targetUrl) {
  const href = location.href;
  const lower = document.documentElement.innerHTML.toLowerCase();
  const title = (document.title || "").toLowerCase();

  // ── 1. HTTP error status via Performance API ──────────────────────────────
  // 403 / 429 / 503 from Google = rate-limit / soft block → signal retry.
  // 404 / 5xx = real error → surface as ERROR.
  try {
    const nav = performance.getEntriesByType("navigation")[0];
    const httpStatus = nav && nav.responseStatus;
    if (httpStatus && httpStatus >= 400) {
      // Soft block — Google is telling us to slow down, not that the URL is bad.
      if (httpStatus === 403 || httpStatus === 429 || httpStatus === 503) {
        return { soft: "HTTP " + httpStatus };
      }
      const labels = { 400: "Bad Request", 404: "Not Found", 500: "Server Error" };
      const label = labels[httpStatus] || "HTTP error";
      return { status: "ERROR", detail: `${httpStatus} ${label} from Google` };
    }
  } catch { /* Performance API unavailable — continue with DOM checks */ }

  // ── 2. CAPTCHA / unusual-traffic page ────────────────────────────────────
  if (href.includes("/sorry/") ||
      document.querySelector("#captcha, .g-recaptcha") ||
      lower.includes("unusual traffic from your computer") ||
      lower.includes("our systems have detected unusual traffic")) {
    return { blocked: "CAPTCHA" };
  }

  // ── 3. Consent / sign-in wall ─────────────────────────────────────────────
  if (href.includes("consent.google") || lower.includes("before you continue to google")) {
    return { blocked: "CONSENT" };
  }

  // ── 4. Error pages rendered as HTML (403/429/503 = soft block → retry) ────
  // Google sometimes delivers these as page content instead of HTTP codes.
  if (lower.includes("403. that’s an error") ||
      lower.includes("403. that's an error") ||
      lower.includes("your client does not have permission") ||
      lower.includes("service unavailable") ||
      lower.includes("429. that's an error") ||
      (title.includes("403") && title.includes("error"))) {
    return { soft: "HTML error page" };   // rate-limit → back off and retry
  }
  if (title.includes("error") && !title.includes("results") ||
      lower.includes("this page is not available")) {
    const code = title.match(/\d{3}/)?.[0] || "";
    return { status: "ERROR", detail: `Google error page${code ? " " + code : ""} — check manually` };
  }

  // ── 5. "Did not match any documents" = definitely not indexed ─────────────
  if (lower.includes("did not match any documents") ||
      lower.includes("- did not match any") ||
      lower.includes("no results found for")) {
    return { status: "NOT_INDEXED", detail: "No results on Google" };
  }

  // ── 6. Result-stats bar is the clearest "there are results" signal ────────
  if (document.querySelector("#result-stats")) {
    return { status: "INDEXED", detail: "Found in Google" };
  }

  // ── 7. Result cards (Google changes selectors often; cover all known) ──────
  const cards = document.querySelectorAll(
    ".tF2Cxc, .g[data-hveid], [data-sokoban-container] .g, .MjjYud .g, .hlcw0c"
  );
  if (cards.length > 0) return { status: "INDEXED", detail: "Found in Google" };

  // ── 8. Fallback: any result link pointing at the target's hostname ─────────
  try {
    const host = new URL(targetUrl).hostname.replace(/^www\./i, "");
    const hit = Array.from(document.querySelectorAll("a[href]")).some((a) => {
      try { return new URL(a.href).hostname.replace(/^www\./i, "").endsWith(host); }
      catch { return false; }
    });
    if (hit) return { status: "INDEXED", detail: "Found in Google" };
  } catch { /* ignore */ }

  // ── 9. Unrecognised page — surface it as an error, not a silent NOT_INDEXED ─
  // This prevents a blank/broken/unexpected Google page from masquerading as
  // "not indexed" and hiding the real problem.
  const bodyLen = (document.body && document.body.innerText.trim().length) || 0;
  if (bodyLen < 200) {
    // Very short page — almost certainly an error, not search results
    return { status: "ERROR", detail: "Unexpected page from Google (check manually)" };
  }

  return { status: "NOT_INDEXED", detail: "No results on Google" };
}

/* Open a real background tab, wait for it to fully render, inject
   extractGoogleResult, then close the tab. Uses the full browser fingerprint
   so Google treats it identically to a human opening a search tab. */
async function scrapeCheck(url) {
  const searchUrl = googleSearchUrl(url);

  return new Promise((resolve) => {
    chrome.tabs.create({ url: searchUrl, active: false }, (tab) => {
      if (chrome.runtime.lastError || !tab) {
        resolve({ status: "ERROR", detail: "Could not open tab" });
        return;
      }
      const tabId = tab.id;

      const cleanup = (result) => {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        clearTimeout(timer);
        chrome.tabs.remove(tabId, () => {});
        resolve(result);
      };

      // 30-second hard timeout per tab
      const timer = setTimeout(() => cleanup({ status: "ERROR", detail: "Timeout" }), 30000);

      function onUpdated(updatedId, changeInfo) {
        if (updatedId !== tabId || changeInfo.status !== "complete") return;
        chrome.scripting.executeScript(
          { target: { tabId }, func: extractGoogleResult, args: [url] },
          (results) => {
            if (chrome.runtime.lastError || !results || !results[0]) {
              cleanup({ status: "ERROR", detail: chrome.runtime.lastError?.message || "Script injection failed" });
              return;
            }
            const res = results[0].result;
            // If CAPTCHA: make the tab visible so user can solve it
            if (res && res.blocked) {
              clearTimeout(timer);
              chrome.tabs.onUpdated.removeListener(onUpdated);
              chrome.tabs.update(tabId, { active: true }); // bring tab to front
              // Don't close — user needs to solve it. Caller handles the pause.
              resolve(res);
              return;
            }
            cleanup(res);
          }
        );
      }

      chrome.tabs.onUpdated.addListener(onUpdated);
    });
  });
}

/* =====================================================================
 * Run loop (shared worker pool for all methods)
 * ===================================================================== */

function setStatus(text, cls) {
  el.runStatus.textContent = text;
  el.runStatus.className = "run-status" + (cls ? " " + cls : "");
}

function randDelayMs() {
  let min = parseFloat(el.minDelay.value) || 0;
  let max = parseFloat(el.maxDelay.value) || 0;
  if (max < min) [min, max] = [max, min];
  return Math.round((min + Math.random() * (max - min)) * 1000);
}

function sleep(ms, checkStop) {
  return new Promise((resolve) => {
    if (ms <= 0) return resolve();
    let waited = 0;
    const iv = setInterval(() => {
      waited += 150;
      if ((checkStop && checkStop()) || waited >= ms) { clearInterval(iv); resolve(); }
    }, 150);
  });
}

function setRunningUI(isRunning) {
  el.startBtn.disabled = isRunning;
  el.stopBtn.disabled = !isRunning;
  el.recheckBtn.disabled = isRunning || !rows.some((r) => r.status === "ERROR");
  el.loadBtn.disabled = isRunning;
  el.clearBtn.disabled = isRunning;
  el.method.disabled = isRunning;
  el.startBtn.textContent = paused ? "▶ Resume" : "▶ Start";
}

async function preflight(method) {
  if (method === "gsc") {
    if (!el.gscClientId.value.trim()) throw new Error("Enter your Google OAuth Client ID and Connect first.");
    await gscEnsureToken();
    if (!gscProperties.length) await gscLoadProperties();
    refreshGscStatus();
    if (!gscProperties.length) throw new Error("No verified Search Console properties on this account.");
  } else if (method === "bing") {
    if (!el.bingApiKey.value.trim()) throw new Error("Enter your Bing API key and Verify first.");
    if (!bingSites.length) await bingLoadSites();
    refreshBingStatus();
  }
}

async function runQueue(targets) {
  const method = el.method.value;
  try { await preflight(method); }
  catch (err) { setStatus("Setup needed", "warn"); alert(err.message); return; }

  running = true; stopRequested = false; paused = false;
  setRunningUI(true);

  const total = targets.length;
  let next = 0, done = 0, blockedOnce = false;
  const isScrape = method === "scrape";
  const adaptive = isScrape && el.adaptive.checked;
  const concurrency = Math.max(1, Math.min(5, parseInt(el.concurrency.value, 10) || 1));

  // Adaptive throttle state (scrape only): mult scales the delay up on
  // pushback and back down after clean streaks, converging on the fastest
  // rate Google tolerates. cooldown handles soft "slow down" (429) blocks.
  let mult = 1;
  let streak = 0;
  const MULT_CAP = 40;              // effective delay ceiling multiplier
  const effectiveDelay = () => Math.min(adaptive ? randDelayMs() * mult : randDelayMs(), 90000);
  function pushback() {             // Google resisted — slow down fast
    if (!adaptive) return;
    mult = Math.min(mult * 2 || 2, MULT_CAP);
    streak = 0;
  }
  function ok() {                   // clean result — gently speed up
    if (!adaptive) return;
    if (++streak >= 8 && mult > 1) { mult = Math.max(1, mult * 0.7); streak = 0; }
  }

  async function worker() {
    while (!stopRequested) {
      const i = next++;
      if (i >= total) return;
      const row = targets[i];
      row.status = "CHECKING"; updateRowInPlace(row);

      let res;
      // For scraping: auto-retry soft blocks (403/429/503) with backoff.
      // These mean "slow down", not "this URL is bad".
      const maxAttempts = isScrape ? 3 : 1;
      for (let attempt = 0; attempt < maxAttempts && !stopRequested; attempt++) {
        try {
          if (method === "gsc") res = await gscCheck(row.url);
          else if (method === "bing") res = await bingCheck(row.url);
          else res = await scrapeCheck(row.url);    // real tab — full browser fingerprint
        } catch (err) {
          res = { status: "ERROR", detail: err.message || "Network error" };
        }

        if (res && res.soft) {
          // Google asked us to slow down — back off and retry this URL.
          pushback();
          const wait = Math.min(4000 * Math.pow(2, attempt), 30000);
          setStatus(`Google rate-limited (${res.soft}) — waiting ${Math.round(wait / 1000)}s, retry ${attempt + 1}/${maxAttempts - 1}…`, "warn");
          await sleep(wait, () => stopRequested);
          continue;   // retry same URL
        }
        break;        // got a real result (or hard block) — stop retrying
      }

      if (res && res.soft) {
        // Still soft-blocked after all retries → mark as error so user can re-check later
        res = { status: "ERROR", detail: `Rate-limited by Google (${res.soft}) — re-check later` };
        pushback();
      }

      if (res && res.blocked) {
        // CAPTCHA tab is already open and brought to front by scrapeCheck.
        // All workers stop; user solves it, hits Resume.
        pushback();
        row.status = "PENDING"; updateRowInPlace(row);
        if (!blockedOnce) {
          blockedOnce = true; paused = true; stopRequested = true;
          const kind = res.blocked === "CAPTCHA" ? "CAPTCHA" : "consent page";
          setStatus(`${kind} appeared in the tab — solve it, then ▶ Resume`, "warn");
        }
        return;
      }

      row.status = res.status; row.detail = res.detail || "";
      if (res.status !== "ERROR") ok(); else pushback();
      row.checkedAt = Date.now();
      done++;
      updateRowInPlace(row); updateCounts(); saveState();

      const speedNote = adaptive && mult > 1 ? ` · pace ×${mult.toFixed(1)}` : "";
      setStatus(`Checking… ${done}/${total} done${speedNote}`, "busy");

      if (next < total && !stopRequested) await sleep(effectiveDelay(), () => stopRequested);
    }
  }

  const workers = [];
  for (let w = 0; w < concurrency; w++) workers.push(worker());
  await Promise.all(workers);

  running = false;
  paused = paused && blockedOnce;
  setRunningUI(false);
  if (!blockedOnce) setStatus(stopRequested ? "Stopped" : "Done", "");
  updateCounts(); saveState();
}

el.startBtn.addEventListener("click", () => {
  if (running) return;
  loadIntoTable();
  const targets = rows.filter((r) => r.status === "PENDING" || r.status === "CHECKING");
  if (!targets.length) { setStatus("Nothing pending", ""); return; }
  runQueue(targets);
});

el.stopBtn.addEventListener("click", () => { stopRequested = true; setStatus("Stopping…", ""); });

el.recheckBtn.addEventListener("click", () => {
  if (running) return;
  const targets = rows.filter((r) => r.status === "ERROR");
  if (!targets.length) return;
  targets.forEach((r) => { r.status = "PENDING"; r.detail = ""; });
  renderTable();
  runQueue(targets);
});

/* ----------------------------- Export ----------------------------- */

function resultsAsRows() {
  return rows.map((r) => [r.url, STATUS_LABEL[r.status] || r.status, r.detail || ""]);
}

el.copyBtn.addEventListener("click", async () => {
  await copyText(resultsAsRows().map((r) => r.join("\t")).join("\n"));
  setStatus("Results copied", "");
});

el.exportCsvBtn.addEventListener("click", () => {
  const lines = [["URL", "Status", "Detail"], ...resultsAsRows()]
    .map((r) => r.map(csvCell).join(",")).join("\r\n");
  const blob = new Blob(["\uFEFF" + lines], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `index-verifier-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-")}.csv`;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});

/* ----------------------------- Utils ----------------------------- */

async function copyText(text) {
  try { await navigator.clipboard.writeText(text); }
  catch {
    const ta = document.createElement("textarea");
    ta.value = text; document.body.appendChild(ta); ta.select();
    document.execCommand("copy"); ta.remove();
  }
}
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function escapeRegex(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }
function cssEscape(s) { return s.replace(/["\\]/g, "\\$&"); }
function csvCell(v) {
  const s = String(v ?? "");
  return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}

/* ----------------------------- Wire-up ----------------------------- */

let draftTimer;
el.urls.addEventListener("input", () => { clearTimeout(draftTimer); draftTimer = setTimeout(saveState, 500); });

/* Paste → auto-format one link per line. If the pasted text holds more than one
   token (links glued together by spaces, commas, etc.), we reformat it so each
   link sits on its own line, inserted at the cursor. A single token pastes
   normally. */
el.urls.addEventListener("paste", (e) => {
  const clip = e.clipboardData || window.clipboardData;
  if (!clip) return;
  const text = clip.getData("text");
  if (!text) return;
  const pieces = splitPastedLinks(text);
  if (pieces.length <= 1) return;           // nothing to reformat — let the browser paste

  e.preventDefault();
  const ta = el.urls;
  const start = ta.selectionStart, end = ta.selectionEnd;
  const before = ta.value.slice(0, start);
  const after = ta.value.slice(end);
  const lead = before && !before.endsWith("\n") ? "\n" : "";
  const trail = after && !after.startsWith("\n") ? "\n" : "";
  const insert = lead + pieces.join("\n") + trail;
  ta.value = before + insert + after;
  const caret = (before + insert).length;
  ta.selectionStart = ta.selectionEnd = caret;
  clearTimeout(draftTimer);
  saveState();
});
[el.minDelay, el.maxDelay, el.region, el.matchMode, el.concurrency, el.adaptive].forEach((c) => c.addEventListener("change", saveState));
el.gscClientId.addEventListener("change", saveState);
el.bingApiKey.addEventListener("input", () => { refreshBingStatus(); });
el.bingApiKey.addEventListener("change", saveState);

loadState();
