# Page Index Verifier

A Chrome/Edge extension that checks whether URLs are **indexed on Google or Bing**.

## Three checking methods

| Method | CAPTCHA? | Setup | Works on |
|---|---|---|---|
| **Google Search Console API** | Never | OAuth (one time) | Sites verified in *your* Search Console |
| **Bing Webmaster API** | Never | API key (one time) | Sites verified in *your* Bing Webmaster Tools |
| **Google search scraping** | Yes (auto-pauses) | None | Any URL |

Pick the method in the **Checking method** dropdown.

## Install (Load unpacked)
1. Open `chrome://extensions` (or `edge://extensions`).
2. Turn on **Developer mode** (top-right).
3. Click **Load unpacked** → select this folder.
4. Click the extension's toolbar icon → the tool opens in a new tab.

## Setup: Google Search Console API (recommended for your sites)
1. **console.cloud.google.com** → create/select a project.
2. **APIs & Services → Library** → enable **Google Search Console API**.
3. **OAuth consent screen** → External → add your own email under **Test users**.
4. **Credentials → Create credentials → OAuth client ID → Web application**.
5. In the extension, copy the **Redirect URI** shown and paste it into the client's
   **Authorized redirect URIs** → Create.
6. Copy the **Client ID** into the extension → **Connect Google**.
- Limits: ~2,000 checks/day per property. Never triggers CAPTCHA.

## Setup: Bing Webmaster API
1. **bing.com/webmasters** → sign in → add & verify your site
   (one-click **Import from Google Search Console** works).
2. Profile → **Settings → API access → API Key** → copy.
3. Paste the key into the extension → **Verify key**.

## Use
1. Paste links (one per line) or **Import CSV / XLSX**.
2. **Load into table** → choose a method → **▶ Start**.
3. Status fills in as **Indexed / Not indexed / Error**, with a **Detail** column
   (e.g. "Submitted and indexed", "Crawled – currently not indexed", "Crawled 2026-08-12").
4. **Copy results** or **Export CSV**.

## Notes
- API keys/tokens are stored only in your browser (`chrome.storage.local`); nothing is sent anywhere except Google/Bing's own APIs.
- `vendor/xlsx.full.min.js` is SheetJS (Apache-2.0), used only to read XLSX files.
- For URLs you don't own, only the scraping method applies and CAPTCHAs are unavoidable at speed — the run pauses so you solve one and Resume.
